package lt.akademine.akademinesistemapraktine.dao;

import lt.akademine.akademinesistemapraktine.model.Grade;
import java.util.List;

public interface IGradeDAO {
    List<Grade> findAll();
    List<Grade> findAllByStudentId(int studentId);
    List<Grade> findAllByTeacherId(int teacherId);
    void save(Grade grade);

}

