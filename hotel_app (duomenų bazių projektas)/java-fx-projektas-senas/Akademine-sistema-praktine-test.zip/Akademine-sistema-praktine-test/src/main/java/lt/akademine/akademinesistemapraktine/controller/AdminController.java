package lt.akademine.akademinesistemapraktine.controller;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import lt.akademine.akademinesistemapraktine.dao.*;
import lt.akademine.akademinesistemapraktine.model.Student;
import lt.akademine.akademinesistemapraktine.model.Teacher;
import lt.akademine.akademinesistemapraktine.model.Subject;
import lt.akademine.akademinesistemapraktine.model.User;

public class AdminController {

    // --- Visi vartotojai (User) ---
    @FXML private TableView<User> usersTable;
    @FXML private TableColumn<User, String> colName;
    @FXML private TableColumn<User, String> colLastname;
    @FXML private TableColumn<User, String> colGroup;

    // --- Studentų kūrimo forma ---
    @FXML private TextField nameField;
    @FXML private TextField lastnameField;
    @FXML private TextField groupField;

    // --- Priskyrimai ---
    @FXML private ComboBox<Teacher> teacherCombo;
    @FXML private ComboBox<Subject> subjectCombo;

    @FXML private Label statusLabel;

    // --- Dalykų lentelė ---
    @FXML private TableView<Subject> subjectTable;
    @FXML private TableColumn<Subject, Number> colSubjectId;
    @FXML private TableColumn<Subject, String> colSubjectName;
    @FXML private TableColumn<Subject, Number> colSubjectTeacher;

    @FXML private TextField newSubjectNameField;

    private final UserDAOImpl userDAO = new UserDAOImpl();
    private final StudentDAOImpl studentDAO = new StudentDAOImpl();
    private final SubjectDAOImpl subjectDAO = new SubjectDAOImpl();
    private final ITeacherDAO teacherDAO = new TeacherDAOImpl();


    // ================================================================
    // INITIALIZE
    // ================================================================

    @FXML
    public void initialize() {

        // --- VISŲ VARTOTOJŲ LENTELĖ ---
        colName.setCellValueFactory(v -> new SimpleStringProperty(v.getValue().getName()));
        colLastname.setCellValueFactory(v -> new SimpleStringProperty(v.getValue().getLastname()));
        colGroup.setCellValueFactory(v ->
                new SimpleStringProperty(v.getValue().getRole())
        );

        // --- DALYKŲ LENTELĖ ---
        colSubjectId.setCellValueFactory(v -> new SimpleIntegerProperty(v.getValue().getSubjectId()));
        colSubjectName.setCellValueFactory(v -> new SimpleStringProperty(v.getValue().getSubjectName()));
        colSubjectTeacher.setCellValueFactory(v ->
                new SimpleIntegerProperty(
                        v.getValue().getTeacherId() == null ? 0 : v.getValue().getTeacherId()
                )
        );


        loadUsers();
        loadTeachers();
        loadSubjects();
    }


    // ================================================================
    //  LOADING
    // ================================================================

    private void loadUsers() {
        usersTable.setItems(
                FXCollections.observableArrayList(userDAO.getAllUsersWithGroup())
        );
    }

    private void loadTeachers() {
        teacherCombo.setItems(FXCollections.observableArrayList(teacherDAO.findAll()));
    }

    private void loadSubjects() {
        subjectTable.setItems(FXCollections.observableArrayList(subjectDAO.findAll()));
        subjectCombo.setItems(FXCollections.observableArrayList(subjectDAO.findAll()));
    }


    // ================================================================
    // VARTOTOJO / STUDENTO KŪRIMAS
    // ================================================================

    @FXML
    private void addUser() {

        if (nameField.getText().isEmpty() ||
                lastnameField.getText().isEmpty() ||
                groupField.getText().isEmpty()) {

            statusLabel.setText("Užpildykite visus laukus!");
            return;
        }

        String name = nameField.getText();
        String lastname = lastnameField.getText();
        String email = (name + "." + lastname).toLowerCase() + "@stud.viko.lt";
        String password = lastname.toLowerCase();

        if (userDAO.existsByEmail(email)) {
            statusLabel.setText("Toks el. paštas jau egzistuoja!");
            return;
        }

        User u = new User();
        u.setName(name);
        u.setLastname(lastname);
        u.setEmail(email);
        u.setPassword(password);
        String role = null;
        switch (Integer.parseInt(groupField.getText())) {
            case 1 -> role = "admin";
            case 2 -> role = "teacher";
            case 3 -> role = "student";
        }
        u.setRole(role);

        int userId = userDAO.save(u);

        if (role.equals("student")) {

            // Sukuriame studentą DB
            Student s = new Student();
            s.setUserId(userId);
            s.setGroupId(Integer.parseInt(groupField.getText()));

            studentDAO.save(s);

            statusLabel.setText("Studentas pridėtas. Slaptažodis: " + password);
            loadUsers();

        }
        else if (role.equals("teacher")) {
            statusLabel.setText("Mokytojas pridėtas! Slaptažodis: " + password);
            teacherDAO.save(new Teacher(userId));
            loadUsers();
            loadTeachers();
        }
        else if(role.equals("admin")) {
            statusLabel.setText("Administratorius pridėtas! Slaptažodis: " + password);
            loadUsers();
        }
        else {
            statusLabel.setText("Nepavyko sukurti vartoto!");
        }


    }


    // ================================================================
    //  STUDENTO TRYNIMAS
    // ================================================================

    @FXML
    private void deleteStudent() {

        User u = usersTable.getSelectionModel().getSelectedItem();

        if (u == null || !"student".equals(u.getRole())) {
            statusLabel.setText("Pasirinkite studentą!");
            return;
        }

        studentDAO.delete(u.getUserId());
        userDAO.delete(u.getUserId());

        statusLabel.setText("Studentas pašalintas!");
        loadUsers();
    }

    @FXML
    private void deleteTeacher() {

        User selected = usersTable.getSelectionModel().getSelectedItem();

        if (selected == null || !"teacher".equals(selected.getRole())) {
            statusLabel.setText("Pasirinkite dėstytoją!");
            return;
        }

        // Salinam įrašą Teachers lentelėje
        teacherDAO.deleteByUserId(selected.getUserId());

        userDAO.delete(selected.getUserId());

        statusLabel.setText("Dėstytojas pašalintas!");

        loadUsers();
        loadTeachers();
    }



    // ================================================================
    // DALYKO PRISKYRIMAS DĖSTYTOJUI
    // ================================================================

    @FXML
    private void assignSubjectToTeacher() {

        Teacher teacher = teacherCombo.getValue();
        Subject subject = subjectCombo.getValue();

        if (teacher == null || subject == null) {
            statusLabel.setText("Pasirinkite dėstytoją ir dalyką!");
            return;
        }

        boolean ok = subjectDAO.assignTeacher(subject.getSubjectId(), teacher.getUserId());

        if (ok) {
            statusLabel.setText("Dalykas priskirtas!");
            loadSubjects();
        } else {
            statusLabel.setText("Nepavyko priskirti dalyko.");
        }
    }


    // ================================================================
    // DALYKŲ KŪRIMAS IR TRYNIMAS
    // ================================================================

    @FXML
    private void addSubject() {

        String name = newSubjectNameField.getText().trim();

        if (name.isEmpty()) {
            statusLabel.setText("Įveskite dalyko pavadinimą!");
            return;
        }

        subjectDAO.save(new Subject(0, name, 0));
        statusLabel.setText("Dalykas sukurtas!");

        loadSubjects();
        newSubjectNameField.clear();
    }

    @FXML
    private void deleteSubject() {

        Subject s = subjectTable.getSelectionModel().getSelectedItem();

        if (s == null) {
            statusLabel.setText("Pasirinkite dalyką!");
            return;
        }

        subjectDAO.delete(s.getSubjectId());
        statusLabel.setText("Dalykas ištrintas!");

        loadSubjects();
    }
}
