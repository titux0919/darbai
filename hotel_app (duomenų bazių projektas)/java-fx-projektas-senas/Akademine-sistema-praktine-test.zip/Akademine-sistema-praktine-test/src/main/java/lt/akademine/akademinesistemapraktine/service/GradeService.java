package lt.akademine.akademinesistemapraktine.service;

import lt.akademine.akademinesistemapraktine.dao.DBConnection;
import lt.akademine.akademinesistemapraktine.dao.GradeDAOImpl;
import lt.akademine.akademinesistemapraktine.dao.IGradeDAO;
import lt.akademine.akademinesistemapraktine.model.Grade;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class GradeService {

    private final IGradeDAO gradeDAO;

    public GradeService() {
        this.gradeDAO = new GradeDAOImpl();
    }

    public List<Grade> getGradesForStudent(int studentId) {
        return gradeDAO.findAllByStudentId(studentId);
    }


    public void updateGrade(Grade grade) {
        String sql = "UPDATE `grades` SET grade = ? WHERE GradeID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, grade.getGradeValue());
            stmt.setInt(2, grade.getId());
            stmt.executeUpdate();

        } catch (Exception e) {
            System.out.println("[ERROR] updateGrade() klaida: " + e.getMessage());
        }
    }

    public void saveGrade(Grade grade) {
        String sql = "INSERT INTO `grades` (StudentID, SubjectID, grade) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, grade.getStudentId());
            stmt.setInt(2, grade.getSubjectId());
            stmt.setInt(3, grade.getGradeValue());
            stmt.executeUpdate();

        } catch (Exception e) {
            System.out.println("[ERROR] saveGrade() klaida: " + e.getMessage());
        }
    }

    public List<Grade> findAllGrades() {
        List<Grade> list = new ArrayList<>();

        String sql = """
    SELECT 
        g.GradeID, 
        g.StudentID, 
        g.SubjectID, 
        g.grade AS GradeValue,
        s.Name AS StudentName,
        sub.SubjectName AS SubjectName
    FROM `grades` g
    JOIN students stu ON g.StudentID = stu.StudentID
    JOIN users s ON stu.UserID = s.UserID
    JOIN subjects sub ON g.SubjectID = sub.SubjectID
""";


        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Grade g = new Grade(
                        rs.getInt("GradeID"),
                        rs.getInt("StudentID"),
                        rs.getInt("SubjectID"),
                        rs.getString("StudentName"),
                        rs.getString("SubjectName"),
                        rs.getInt("GradeValue")
                );

                // tableview rodomi pavadinimai
                g.setStudentName(rs.getString("StudentName"));
                g.setSubjectName(rs.getString("SubjectName"));

                list.add(g);
            }

        } catch (Exception e) {
            System.out.println("[ERROR] findAllGrades() klaida: " + e.getMessage());
        }

        return list;
    }

    public List<Grade> getGradesForTeacher(int teacherId) {
        return gradeDAO.findAllByTeacherId(teacherId);
    }

}

