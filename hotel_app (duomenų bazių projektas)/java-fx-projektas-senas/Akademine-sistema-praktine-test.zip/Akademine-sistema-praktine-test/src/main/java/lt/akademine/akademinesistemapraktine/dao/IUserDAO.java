package lt.akademine.akademinesistemapraktine.dao;

import lt.akademine.akademinesistemapraktine.model.User;

import java.util.List;

public interface IUserDAO {

    /**
     * Prisijungimo užklausa pagal email + slaptažodį.
     */
    User findByCredentials(String email, String password);

    /**
     * Naujo vartotojo išsaugojimas.
     *
     * @return sugeneruotas UserID arba -1, jei nepavyko
     */
    int save(User user);

    /**
     * Vartotojo ištrynimas pagal UserID.
     */
    void delete(int userId);

    /**
     * Gauna visus vartotojus
     */
    List<User> getAllUsers();

}
