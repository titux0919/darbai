package lt.akademine.akademinesistemapraktine.dao;

import lt.akademine.akademinesistemapraktine.model.Student;
import java.util.List;

public interface IStudentDAO {
    void save(Student student);
    void delete(int studentId);
    List<Student> findAll();
}

