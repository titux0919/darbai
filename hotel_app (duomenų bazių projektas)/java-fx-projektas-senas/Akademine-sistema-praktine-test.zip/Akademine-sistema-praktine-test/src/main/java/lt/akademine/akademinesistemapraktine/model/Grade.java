package lt.akademine.akademinesistemapraktine.model;

import javafx.beans.property.*;

public class Grade {

    private IntegerProperty id;
    private IntegerProperty studentId;
    private IntegerProperty subjectId;
    private StringProperty studentName;
    private StringProperty subjectName;
    private IntegerProperty gradeValue;

    // Konstruktoris
    public Grade() {
        this.id = new SimpleIntegerProperty(0);
        this.studentId = new SimpleIntegerProperty(0);
        this.subjectId = new SimpleIntegerProperty(0);
        this.gradeValue = new SimpleIntegerProperty(0);
        this.studentName = new SimpleStringProperty("");
        this.subjectName = new SimpleStringProperty("");
    }

    // Konstruktoris naujam įrašui
    public Grade(int studentId, int subjectId, int gradeValue) {
        this();
        this.studentId.set(studentId);
        this.subjectId.set(subjectId);
        this.gradeValue.set(gradeValue);
    }

    // Pilnas konstruktorius iš DB
    public Grade(int id, int studentId, int subjectId,
                 String studentName, String subjectName, int gradeValue) {

        this();
        this.id.set(id);
        this.studentId.set(studentId);
        this.subjectId.set(subjectId);
        this.studentName.set(studentName);
        this.subjectName.set(subjectName);
        this.gradeValue.set(gradeValue);
    }

    // GET
    public int getId() { return id.get(); }
    public int getStudentId() { return studentId.get(); }
    public int getSubjectId() { return subjectId.get(); }
    public int getGradeValue() { return gradeValue.get(); }

    // SET
    public void setStudentId(int id) { this.studentId.set(id); }
    public void setSubjectId(int id) { this.subjectId.set(id); }
    public void setGradeValue(int value) { this.gradeValue.set(value); }
    public void setStudentName(String name) { this.studentName.set(name); }
    public void setSubjectName(String name) { this.subjectName.set(name); }

    // PROPERTIES
    public IntegerProperty gradeValueProperty() { return gradeValue; }
    public StringProperty studentNameProperty() { return studentName; }
    public StringProperty subjectNameProperty() { return subjectName; }


    public void setGradeId(int gradeID) {
        this.gradeValue.set(gradeID);
    }
}
