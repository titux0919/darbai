package lt.akademine.akademinesistemapraktine.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import lt.akademine.akademinesistemapraktine.dao.StudentDAOImpl;
import lt.akademine.akademinesistemapraktine.model.Grade;
import lt.akademine.akademinesistemapraktine.model.Student;
import lt.akademine.akademinesistemapraktine.model.User;
import lt.akademine.akademinesistemapraktine.service.GradeService;

import java.util.List;

public class StudentController {

    @FXML
    private TableView<Grade> studentGrades;

    @FXML
    private TableColumn<Grade, String> colSubject;

    @FXML
    private TableColumn<Grade, Integer> colGrade;

    @FXML
    private Label statusLabel;

    private final GradeService gradeService = new GradeService();
    private final StudentDAOImpl studentDAO = new StudentDAOImpl();

    private User loggedUser;
    private int loggedStudentId;

    @FXML
    public void initialize() {
        colSubject.setCellValueFactory(new PropertyValueFactory<>("subjectName"));
        colGrade.setCellValueFactory(new PropertyValueFactory<>("gradeValue"));
    }

    /**
     * PERDUODA PRISIJUNGUSĮ USER (iš LoginController)
     */
    public void setStudent(User user) {
        this.loggedUser = user;

        System.out.println("[DEBUG] Student prisijungė: " + user.getEmail());

        Student student = studentDAO.findByUserId(user.getUserId());

        if (student != null) {
            loggedStudentId = student.getStudentId();
            System.out.println("[DEBUG] StudentID rastas: " + loggedStudentId);
        } else {
            System.out.println("[ERROR] Nerastas studentas pagal UserID: " + user.getUserId());
        }

        loadMyGrades();
    }

    /**
     * Užkrauna tik prisijungusio studento pažymius
     */
    private void loadMyGrades() {
        try {
            List<Grade> grades = gradeService.getGradesForStudent(loggedStudentId);

            System.out.println("[DEBUG] Rasta pažymių: " + grades.size());

            studentGrades.getItems().setAll(grades);
        } catch (Exception e) {
            statusLabel.setText("Klaida kraunant pažymius: " + e.getMessage());
            System.out.println("[ERROR] loadMyGrades(): " + e.getMessage());
        }
    }
}
