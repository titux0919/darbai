package lt.akademine.akademinesistemapraktine.dao;

import lt.akademine.akademinesistemapraktine.model.Subject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SubjectDAOImpl implements ISubjectDAO {

    @Override
    public List<Subject> findAll() {
        List<Subject> list = new ArrayList<>();

        String sql = "SELECT SubjectID, SubjectName, TeacherID FROM subjects";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(new Subject(
                        rs.getInt("SubjectID"),
                        rs.getString("SubjectName"),
                        rs.getInt("TeacherID")
                ));
            }

        } catch (Exception e) {
            System.out.println("[ERROR] Dalykų užklausos klaida: " + e.getMessage());
        }

        return list;
    }

    @Override
    public List<Subject> findByTeacherId(int teacherId) {
        List<Subject> list = new ArrayList<>();

        String sql = "SELECT SubjectID, SubjectName, TeacherID FROM subjects WHERE TeacherID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, teacherId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                list.add(new Subject(
                        rs.getInt("SubjectID"),
                        rs.getString("SubjectName"),
                        rs.getInt("TeacherID")
                ));
            }

        } catch (Exception e) {
            System.out.println("[ERROR] Dalykų filtravimo pagal dėstytoją klaida: " + e.getMessage());
        }

        return list;
    }

    @Override
    public boolean assignTeacher(int subjectId, int teacherId) {
        String sql = "UPDATE subjects SET TeacherID = ? WHERE SubjectID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, teacherId);
            stmt.setInt(2, subjectId);

            int rows = stmt.executeUpdate();
            return rows > 0;

        } catch (Exception e) {
            System.out.println("[ERROR] Dalyko priskyrimo klaida: " + e.getMessage());
            return false;
        }
    }

    @Override
    public void save(Subject subject) {
        String sql = "INSERT INTO subjects (SubjectName, TeacherID) VALUES (?, NULL)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, subject.getSubjectName());
            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Klaida kuriant dalyką: " + e.getMessage(), e);
        }
    }

    @Override
    public void delete(int subjectId) {
        String sql = "DELETE FROM subjects WHERE SubjectID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, subjectId);
            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Klaida trinant dalyką: " + e.getMessage(), e);
        }
    }


}
