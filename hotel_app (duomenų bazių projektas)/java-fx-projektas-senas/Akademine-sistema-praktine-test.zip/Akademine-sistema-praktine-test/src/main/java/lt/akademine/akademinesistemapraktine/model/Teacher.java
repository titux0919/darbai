package lt.akademine.akademinesistemapraktine.model;

public class Teacher extends User {

    private int teacherId;     // Turi atskira TeacherID
    private String subjectName;


    // === Paprastas konstruktorius mokytojo sukūrimui ===
    public Teacher(int userId) {
        super.setUserId(userId);
    }

    // === Pilnas konstruktorius naudojamas DAO ===
    public Teacher(int userId, String name, String lastname, String email, String role, String subjectName) {
        super.setUserId(userId);
        super.setName(name);
        super.setLastname(lastname);
        super.setEmail(email);
        super.setRole(role);
        this.subjectName = subjectName;
    }

    public int getTeacherId() {
        return teacherId;
    }
    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    @Override
    public String toString() {
        return getName() + " " + getLastname() + " – " + subjectName;
    }
}
