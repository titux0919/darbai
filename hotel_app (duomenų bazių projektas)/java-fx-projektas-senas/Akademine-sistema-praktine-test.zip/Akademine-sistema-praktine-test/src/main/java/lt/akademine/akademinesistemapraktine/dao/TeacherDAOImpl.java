package lt.akademine.akademinesistemapraktine.dao;

import lt.akademine.akademinesistemapraktine.model.Teacher;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TeacherDAOImpl implements ITeacherDAO {

    @Override
    public Teacher findById(int id) {

        String sql = """
            SELECT u.UserID, u.Name, u.Lastname, u.Email, u.Role,
                   s.SubjectName
            FROM teachers t
            JOIN users u ON t.UserID = u.UserID
            LEFT JOIN subjects s ON s.TeacherID = t.UserID
            WHERE t.UserID = ?
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Teacher(
                        rs.getInt("UserID"),
                        rs.getString("Name"),
                        rs.getString("Lastname"),
                        rs.getString("Email"),
                        rs.getString("Role"),
                        rs.getString("SubjectName")
                );
            }

        } catch (Exception e) {
            System.out.println("[ERROR] Teacher užklausos klaida: " + e.getMessage());
        }

        return null;
    }

    @Override
    public void save(Teacher teacher) {
        String sql = "INSERT INTO teachers (UserID) VALUES (?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, teacher.getUserId());
            stmt.executeUpdate();

            System.out.println("[INFO] Mokytojas įrašytas į DB.");
        } catch (Exception e) {
            System.out.println("[ERROR] Mokytojo įrašymo klaida: " + e.getMessage());
        }
    }

    @Override
    public void assignSubject(int teacherId, int subjectId) {

        String sql = "UPDATE subjects SET TeacherID = ? WHERE SubjectID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, teacherId);
            stmt.setInt(2, subjectId);
            stmt.executeUpdate();

            System.out.println("[INFO] Dalykas priskirtas dėstytojui.");

        } catch (Exception e) {
            System.out.println("[ERROR] Dalyko priskyrimo klaida: " + e.getMessage());
        }
    }

    @Override
    public void deleteByUserId(int userId) {
        String sql = "DELETE FROM teachers WHERE UserID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Teacher> findAll() {

        List<Teacher> list = new ArrayList<>();

        String sql = """
            SELECT u.UserID, u.Name, u.Lastname, u.Email, u.Role,
                   s.SubjectName
            FROM teachers t
            JOIN users u ON t.UserID = u.UserID
            LEFT JOIN subjects s ON s.TeacherID = t.UserID
            ORDER BY u.Lastname
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(new Teacher(
                        rs.getInt("UserID"),
                        rs.getString("Name"),
                        rs.getString("Lastname"),
                        rs.getString("Email"),
                        rs.getString("Role"),
                        rs.getString("SubjectName")
                ));
            }

        } catch (Exception e) {
            System.out.println("[ERROR] Visių dėstytojų užklausos klaida: " + e.getMessage());
        }


        return list;
    }
}
