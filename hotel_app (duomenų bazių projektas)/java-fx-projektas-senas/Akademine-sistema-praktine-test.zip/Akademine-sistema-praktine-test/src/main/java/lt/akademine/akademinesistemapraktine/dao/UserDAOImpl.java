package lt.akademine.akademinesistemapraktine.dao;

import lt.akademine.akademinesistemapraktine.model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAOImpl implements IUserDAO {

    @Override
    public User findByCredentials(String name, String password) {
        String sql = "SELECT * FROM users WHERE name = ? AND password = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, password);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setUserId(rs.getInt("UserID"));
                    user.setName(rs.getString("name"));
                    user.setLastname(rs.getString("lastname"));
                    user.setEmail(rs.getString("email"));
                    user.setRole(rs.getString("role"));
                    user.setPassword(rs.getString("password")); // <-- PRIDĖTA
                    return user;
                }

            }

        } catch (SQLException e) {
            System.err.println("[ERROR] findByCredentials klaida: " + e.getMessage());
        }

        return null;
    }

    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();

        String sql = "SELECT * FROM users";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                User u = new User();
                u.setUserId(rs.getInt("UserID"));
                u.setName(rs.getString("Name"));
                u.setLastname(rs.getString("Lastname"));
                u.setEmail(rs.getString("Email"));
                u.setRole(rs.getString("Role"));
                list.add(u);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<User> getAllUsersWithGroup() {
        List<User> list = new ArrayList<>();

        String sql =
                "SELECT u.*, g.GroupName " +
                        "FROM users u " +
                        "LEFT JOIN students s ON s.UserID = u.UserID " +
                        "LEFT JOIN `groups` g ON g.GroupID = s.GroupID";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                User u = new User();
                u.setUserId(rs.getInt("UserID"));
                u.setName(rs.getString("Name"));
                u.setLastname(rs.getString("Lastname"));
                u.setEmail(rs.getString("Email"));
                u.setRole(rs.getString("Role"));
                u.setGroupName(rs.getString("GroupName")); // null → "" lentelėje

                list.add(u);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }


    @Override
    public int save(User user) {
        String sql = "INSERT INTO users (name, lastname, email, role, password) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, user.getName());
            stmt.setString(2, user.getLastname());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getRole());
            stmt.setString(5, user.getPassword());

            int affected = stmt.executeUpdate();
            if (affected == 0) {
                System.err.println("[WARN] Nepavyko įterpti vartotojo – nebuvo paveikta eilučių.");
                return -1;
            }

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    int id = keys.getInt(1);
                    user.setUserId(id);
                    return id;
                }
            }

        } catch (SQLException e) {
            System.err.println("[ERROR] save(User) klaida: " + e.getMessage());
        }

        return -1;
    }

    @Override
    public void delete(int userId) {
        String sql = "DELETE FROM users WHERE UserID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.err.println("[ERROR] delete(userId) klaida: " + e.getMessage());
        }
    }

    public boolean existsByEmail(String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE Email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (Exception e) {
            System.out.println("[ERROR] existsByEmail: " + e.getMessage());
        }
        return false;
    }
}

