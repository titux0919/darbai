package lt.akademine.akademinesistemapraktine.dao;

import lt.akademine.akademinesistemapraktine.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAOImpl implements IStudentDAO {

    @Override
    public void save(Student student) {

        String sql = "INSERT INTO students (UserID, GroupID) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, student.getUserId());
            ps.setInt(2, student.getGroupId());

            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Klaida kuriant studentą: " + e.getMessage());
        }
    }

    @Override
    public void delete(int studentId) {
        String sql = "DELETE FROM students WHERE StudentID=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, studentId);
            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Klaida trinant studentą: " + e.getMessage());
        }
    }

    @Override
    public List<Student> findAll() {
        List<Student> list = new ArrayList<>();

        String sql = """
        SELECT s.StudentID, s.UserID, s.GroupID,
               u.name, u.lastname,
               g.GroupName
        FROM students s
        JOIN users u ON s.UserID = u.UserID
        JOIN `groups` g ON s.GroupID = g.GroupID
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new Student(
                        rs.getInt("StudentID"),
                        rs.getInt("UserID"),
                        rs.getInt("GroupID"),
                        rs.getString("name"),
                        rs.getString("lastname"),
                        rs.getString("GroupName")
                ));
            }
        } catch (Exception e) {
            System.out.println("[ERROR] Studentų užklausos klaida: " + e.getMessage());
        }

        return list;
    }

    public Student findByUserId(int userId) {
        String sql = """
        SELECT s.StudentID, s.UserID, s.GroupID, u.name, u.lastname
        FROM students s
        JOIN users u ON s.UserID = u.UserID
        WHERE s.UserID = ?
    """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Student(
                        rs.getInt("StudentID"),
                        rs.getInt("UserID"),
                        rs.getInt("GroupID"),
                        rs.getString("name"),
                        rs.getString("lastname"),
                        "" // jei turi groupName, įdėsi
                );
            }

        } catch (Exception e) {
            System.out.println("[ERROR] findByUserId: " + e.getMessage());
        }

        return null;
    }


}
