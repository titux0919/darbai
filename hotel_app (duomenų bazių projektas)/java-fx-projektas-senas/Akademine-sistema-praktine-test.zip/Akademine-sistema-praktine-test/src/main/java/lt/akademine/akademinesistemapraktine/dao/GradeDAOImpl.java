package lt.akademine.akademinesistemapraktine.dao;

import lt.akademine.akademinesistemapraktine.model.Grade;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GradeDAOImpl implements IGradeDAO {

    @Override
    public List<Grade> findAll() {
        List<Grade> grades = new ArrayList<>();

        String sql = """
            SELECT g.GradeID, g.StudentID, g.SubjectID, g.grade,
                   u.email AS studentName,
                   sub.SubjectName AS subjectName
            FROM `grades` g
            JOIN students s ON g.StudentID = s.StudentID
            JOIN users u ON s.UserID = u.UserID
            JOIN subjects sub ON g.SubjectID = sub.SubjectID
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Grade grade = new Grade(
                        rs.getInt("GradeID"),
                        rs.getInt("StudentID"),
                        rs.getInt("SubjectID"),
                        rs.getString("StudentName"),
                        rs.getString("SubjectName"),
                        rs.getInt("GradeValue")
                );

                grade.setStudentName(rs.getString("studentName"));
                grade.setSubjectName(rs.getString("subjectName"));

                grades.add(grade);
            }

        } catch (SQLException e) {
            System.err.println("[ERROR] Klaida kraunant visus pazymius: " + e.getMessage());
        }

        return grades;
    }


    @Override
    public List<Grade> findAllByTeacherId(int teacherId) {

        System.out.println("[DEBUG] findAllByTeacherId() gautas teacherId = " + teacherId);

        List<Grade> grades = new ArrayList<>();

        String sql = """
        SELECT g.GradeID, g.StudentID, g.SubjectID, g.grade AS GradeValue,
               CONCAT(u.Name, ' ', u.Lastname) AS StudentName,
               sub.SubjectName AS SubjectName
        FROM grades g
        JOIN students s ON g.StudentID = s.StudentID
        JOIN users u ON s.UserID = u.UserID
        JOIN subjects sub ON g.SubjectID = sub.SubjectID
        WHERE sub.TeacherID = ?
    """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, teacherId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Grade grade = new Grade(
                        rs.getInt("GradeID"),
                        rs.getInt("StudentID"),
                        rs.getInt("SubjectID"),
                        rs.getString("StudentName"),
                        rs.getString("SubjectName"),
                        rs.getInt("GradeValue")     // <-- veikia, nes alias padarytas
                );

                grades.add(grade);
            }

        } catch (SQLException e) {
            System.err.println("[ERROR] Klaida kraunant pažymius pagal dėstytoją: " + e.getMessage());
        }

        System.out.println("[DEBUG] findAllByTeacherId() rasta įrašų: " + grades.size());
        return grades;
    }


    @Override
    public List<Grade> findAllByStudentId(int studentId) {
        List<Grade> grades = new ArrayList<>();

        String sql = """
        SELECT g.GradeID, g.StudentID, g.SubjectID, g.grade AS GradeValue,
               sub.SubjectName AS SubjectName
        FROM grades g
        JOIN subjects sub ON g.SubjectID = sub.SubjectID
        WHERE g.StudentID = ?
    """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                Grade grade = new Grade();
                grade.setGradeId(rs.getInt("GradeID"));
                grade.setStudentId(rs.getInt("StudentID"));
                grade.setSubjectId(rs.getInt("SubjectID"));
                grade.setGradeValue(rs.getInt("GradeValue"));
                grade.setSubjectName(rs.getString("SubjectName"));
                grade.setStudentName(""); // studentui nereikia rodyti savo vardo

                grades.add(grade);
            }

        } catch (SQLException e) {
            System.err.println("[ERROR] Klaida kraunant studento pazymius: " + e.getMessage());
        }

        return grades;
    }

    @Override
    public void save(Grade grade) {
        String sql = "INSERT INTO grades (StudentID, SubjectID, grade) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, grade.getStudentId());
            stmt.setInt(2, grade.getSubjectId());
            stmt.setDouble(3, grade.getGradeValue());
            stmt.executeUpdate();

            System.out.println("[OK] Pažymys įrašytas.");

        } catch (SQLException e) {
            System.err.println("[ERROR] Klaida įrašant pažymį: " + e.getMessage());
        }
    }

}
