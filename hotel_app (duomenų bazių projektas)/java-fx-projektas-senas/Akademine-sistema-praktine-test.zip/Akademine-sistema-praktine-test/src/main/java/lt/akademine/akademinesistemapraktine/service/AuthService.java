package lt.akademine.akademinesistemapraktine.service;

import lt.akademine.akademinesistemapraktine.dao.IUserDAO;
import lt.akademine.akademinesistemapraktine.dao.UserDAOImpl;
import lt.akademine.akademinesistemapraktine.model.User;

public class AuthService {

    private final IUserDAO userDAO;

    public AuthService() {
        this.userDAO = new UserDAOImpl();
    }

    public User login(String username, String password) throws Exception {
        if (username == null || username.isEmpty()) {
            throw new Exception("Vartotojo vardas negali būti tuščias!");
        }
        if (password == null || password.isEmpty()) {
            throw new Exception("Slaptažodis negali būti tuščias!");
        }

        User user = userDAO.findByCredentials(username, password);

        if (user == null) {
            throw new Exception("Neteisingas vartotojo vardas arba slaptažodis.");
        }

        return user;
    }
}
