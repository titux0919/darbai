package lt.akademine.akademinesistemapraktine.dao;

import lt.akademine.akademinesistemapraktine.model.Teacher;
import java.util.List;

public interface ITeacherDAO {

    Teacher findById(int id);
    List<Teacher> findAll();
    void assignSubject(int teacherId, int subjectId);
    void save(Teacher teacher);
    void deleteByUserId(int userId);
}
