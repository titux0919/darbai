package lt.akademine.akademinesistemapraktine.model;

public class Student extends User {

    private int studentId;
    private int groupId;
    private String groupName;

    // Tuščias konstruktorius (būtinas JavaFX, ORM, Reflection)
    public Student() {
    }

    public Student(int studentId,
                   int userId,
                   int groupId,
                   String name,
                   String lastname,
                   String groupName) {
        this.studentId = studentId;
        super.setUserId(userId);
        this.groupId = groupId;
        super.setName(name);
        super.setLastname(lastname);
        this.groupName = groupName;
    }

    // ========================
    // GETTERIAI / SETTERIAI
    // ========================

    public int getStudentId() {
        return studentId;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    // ========================
    // toString (naudojama TableView ir ComboBox)
    // ========================

    @Override
    public String toString() {
        return getName() + " " + getLastname() + " (" + groupName + ")";
    }
}
