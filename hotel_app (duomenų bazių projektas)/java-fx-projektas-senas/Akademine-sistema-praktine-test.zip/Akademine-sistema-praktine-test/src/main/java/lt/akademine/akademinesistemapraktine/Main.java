package lt.akademine.akademinesistemapraktine;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application{
    @Override
    public void start(Stage stage) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/lt/akademine/akademinesistemapraktine/login-view.fxml"));
            Scene scene = new Scene(loader.load());
            stage.setTitle("Akademinė informacinė sistema");
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // ← parodys klaida
        }
    }

    public static void main(String[] args) {
        launch();
    }
}

