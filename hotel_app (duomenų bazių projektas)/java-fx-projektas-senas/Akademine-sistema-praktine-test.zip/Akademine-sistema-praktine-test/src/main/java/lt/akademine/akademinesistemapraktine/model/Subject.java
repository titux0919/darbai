package lt.akademine.akademinesistemapraktine.model;

public class Subject {

    private int subjectId;
    private String subjectName;
    private Integer teacherId; // gali būti NULL

    public Subject(int subjectId, String subjectName, Integer teacherId) {
        this.subjectId = subjectId;
        this.subjectName = subjectName;
        this.teacherId = teacherId;
    }

    public int getSubjectId() {
        return subjectId;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    @Override
    public String toString() {
        return getSubjectName();
    }
}
