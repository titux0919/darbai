package lt.akademine.akademinesistemapraktine.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import lt.akademine.akademinesistemapraktine.model.User;
import lt.akademine.akademinesistemapraktine.service.AuthService;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label statusLabel;

    private final AuthService authService = new AuthService();

    @FXML
    private void handleLogin(ActionEvent event) {
        try {
            // Prisijungimas per AuthService
            User user = authService.login(usernameField.getText(), passwordField.getText());

            // Jeigu prisijungimas sėkmingas
            switch (user.getRole()) {
                case "teacher":
                {
                    openView("teacher-view.fxml", user);
                    break;
                }
                case "admin":
                {
                    openView("admin-view.fxml", user);
                    break;
                }
                case "student":
                    openView("student-view.fxml", user);
                    break;
                }

        } catch (Exception e) {
            statusLabel.setText(e.getMessage());
        }
    }

    private void openView(String fxml, User user) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/lt/akademine/akademinesistemapraktine/" + fxml));
            Parent root = loader.load();

            // Jeigu tai dėstytojo vaizdas – perduodame user objektą
            if (fxml.contains("teacher")) {
                TeacherController controller = loader.getController();
                controller.setTeacher(user);
            }
            else if(fxml.contains("student")) {
                StudentController controller = loader.getController();
                controller.setStudent(user);
            }

            // Sukuriame naują langą
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            // Uždaryti login langą
            Stage currentStage = (Stage) usernameField.getScene().getWindow();
            currentStage.close();

        } catch (Exception e) {
            e.printStackTrace();
            statusLabel.setText("Nepavyko įkelti lango: " + e.getMessage());
        }
    }
}
