package lt.akademine.akademinesistemapraktine.model;

public class User {

    private int userId;
    private String name;
    private String lastname;
    private String email;
    private String role;
    private String password;

    private String groupName;

    public String getGroupName() {
        return groupName;
    }

    public User() {}

    // GETTERS
    public int getUserId() {
        return userId;
    }

    public int getId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getLastname() {
        return lastname;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }

    public String getPassword() {
        return password;
    }

    // SETTERS

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
}
