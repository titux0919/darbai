package lt.akademine.akademinesistemapraktine.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import lt.akademine.akademinesistemapraktine.dao.StudentDAOImpl;
import lt.akademine.akademinesistemapraktine.dao.SubjectDAOImpl;
import lt.akademine.akademinesistemapraktine.dao.TeacherDAOImpl;
import lt.akademine.akademinesistemapraktine.model.*;
import lt.akademine.akademinesistemapraktine.service.GradeService;

public class TeacherController {

    @FXML private ComboBox<Student> studentCombo;
    @FXML private ComboBox<Subject> subjectCombo;
    @FXML private TextField gradeField;

    @FXML private TableView<Grade> gradeTable;
    @FXML private TableColumn<Grade, String> studentCol;
    @FXML private TableColumn<Grade, String> subjectCol;
    @FXML private TableColumn<Grade, Number> gradeCol;

    @FXML private Label statusLabel;

    private final StudentDAOImpl studentDAO = new StudentDAOImpl();
    private final SubjectDAOImpl subjectDAO = new SubjectDAOImpl();
    private final GradeService gradeService = new GradeService();
    private final TeacherDAOImpl teacherDAO = new TeacherDAOImpl();


    private User teacher;
    private int teacherId;

    @FXML
    public void initialize() {
        loadStudents();
        loadSubjects();
        setupColumns();
        refreshTable();
    }

    private void loadStudents() {
        studentCombo.setItems(
                FXCollections.observableArrayList(studentDAO.findAll())
        );
    }

    private void loadSubjects_teacher() {
        subjectCombo.setItems(
                FXCollections.observableArrayList(
                        subjectDAO.findByTeacherId(teacherId)
                )
        );
    }


    private void loadSubjects() {
        subjectCombo.setItems(
                FXCollections.observableArrayList(subjectDAO.findAll())
        );
    }

    private void setupColumns() {
        studentCol.setCellValueFactory(g -> g.getValue().studentNameProperty());
        subjectCol.setCellValueFactory(g -> g.getValue().subjectNameProperty());
        gradeCol.setCellValueFactory(g -> g.getValue().gradeValueProperty());
    }

    private void refreshTable() {
        gradeTable.setItems(
                FXCollections.observableArrayList(gradeService.findAllGrades())
        );
    }

    private void refreshTable_teacher() {
        gradeTable.setItems(
                FXCollections.observableArrayList(
                        gradeService.getGradesForTeacher(teacherId)
                )
        );
    }

    @FXML
    private void addGrade() {
        Student student = studentCombo.getValue();
        Subject subject = subjectCombo.getValue();

        if (student == null || subject == null) {
            statusLabel.setText("Pasirinkite studentą ir dalyką!");
            return;
        }

        try {
            int value = Integer.parseInt(gradeField.getText());

            Grade grade = new Grade(student.getStudentId(), subject.getSubjectId(), value);
            gradeService.saveGrade(grade);

            statusLabel.setText("Pažymys sėkmingai pridėtas!");
            refreshTable_teacher();

        } catch (NumberFormatException e) {
            statusLabel.setText("Neteisingas pažymio formatas!");
        }
    }

    @FXML
    private void updateGrade() {
        Grade selected = gradeTable.getSelectionModel().getSelectedItem();

        if (selected == null) {
            statusLabel.setText("Pasirinkite pažymį iš lentelės!");
            return;
        }

        try {
            int newValue = Integer.parseInt(gradeField.getText());
            selected.setGradeValue(newValue);

            gradeService.updateGrade(selected);

            statusLabel.setText("Pažymys atnaujintas!");
            refreshTable_teacher();

        } catch (NumberFormatException e) {
            statusLabel.setText("Neteisingas pažymio formatas!");
        }
    }

    public void setTeacher(User user) {
        this.teacher = user;

        Teacher t = teacherDAO.findById(user.getUserId());
        this.teacherId = t.getUserId();

        loadSubjects_teacher();
        loadStudents();
        refreshTable_teacher();
    }
}
