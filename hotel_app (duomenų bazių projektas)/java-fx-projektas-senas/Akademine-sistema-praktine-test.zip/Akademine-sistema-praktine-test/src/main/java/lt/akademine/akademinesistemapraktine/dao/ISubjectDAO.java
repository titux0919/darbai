package lt.akademine.akademinesistemapraktine.dao;

import lt.akademine.akademinesistemapraktine.model.Subject;
import java.util.List;

public interface ISubjectDAO {

    List<Subject> findAll();

    List<Subject> findByTeacherId(int teacherId);

    boolean assignTeacher(int subjectId, int teacherId);

    void save(Subject subject);
    void delete(int subjectId);
}

