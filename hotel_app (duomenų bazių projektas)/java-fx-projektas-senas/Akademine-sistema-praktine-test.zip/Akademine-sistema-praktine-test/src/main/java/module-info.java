module lt.akademine.akademinesistemapraktine {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires java.sql;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;

    // Leidimai FXML'ui
    opens lt.akademine.akademinesistemapraktine to javafx.fxml;
    opens lt.akademine.akademinesistemapraktine.controller to javafx.fxml;

    // 👇 Šitas leidžia PropertyValueFactory pasiekti tavo modelio laukus
    opens lt.akademine.akademinesistemapraktine.model to javafx.base;

    exports lt.akademine.akademinesistemapraktine;
}
